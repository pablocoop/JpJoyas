@props(['class' => ''])
<div {{ $attributes->merge(['class' => 'flex items-center justify-center ' . $class]) }}>
    <h1 class="font-dragonwick text-2xl sm:text-2xl md:text-3xl lg:text-4xl  text-gray-800 mb-4 tracking-tight text-center">
        JP 
        <br>
        Joyas
    </h1>
</div>