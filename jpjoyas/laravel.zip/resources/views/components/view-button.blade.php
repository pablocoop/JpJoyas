<a {{ $attributes->merge(['class' => 'inline-flex items-center gap-2 px-3 py-2 bg-blue-100 text-blue-800 rounded-md hover:bg-blue-200 transition']) }}>
    <x-lucide-eye class="w-5 h-5" />
    <span>Ver más</span>
</a>
