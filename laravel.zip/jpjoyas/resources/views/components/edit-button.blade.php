<a {{ $attributes->merge(['class' => 'inline-flex items-center p-2 bg-blue-100 text-blue-800 rounded-md hover:bg-blue-200 transition']) }}>
    <x-lucide-edit-2 class="w-5 h-5 fill-current" />
</a>
