<div class="trix-content">
<?php if(trim($trixContent = $content->renderWithAttachments())): ?>
    <?php echo $trixContent; ?>

<?php endif; ?>
</div>
<?php /**PATH C:\Users\pablo\OneDrive\Documentos\JpJoyas\JpJoyas\jpjoyas\vendor\tonysm\rich-text-laravel\resources\views\content.blade.php ENDPATH**/ ?>