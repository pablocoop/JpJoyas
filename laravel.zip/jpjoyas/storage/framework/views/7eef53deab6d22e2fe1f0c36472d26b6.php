<?php $__env->startSection('content'); ?>
<div class="max-w-5xl mx-auto px-6 py-8 bg-gray-300/70 backdrop-blur rounded-lg mt-8">
    
  
  <section id="titulo" class="mb-4 text-center">
    <h1 class="font-dragonwick text-[2.75rem] sm:text-5xl md:text-6xl lg:text-7xl  text-gray-800 mb-2 tracking-tight text-center">
      JP Joyas
    </h1>
    <p class="text-lg text-gray-700 font-dragonwick">
      Joyeria&nbsp;  online&nbsp; de Villarrica.
    </p>
    <div class="border border-gray-500 rounded-lg px-6 py-4 inline-block mt-4">
      <p class=" text-lg text-gray-700 mb-4">
        Accede al catálogo de mis redes sociales
      </p>

      <div class="flex justify-center space-x-6">
        <a href="https://wa.me/message/RCSEZTH4EZGMA1" target="_blank" class="text-black hover:text-gray-700 text-3xl" aria-label="WhatsApp">
          <i class="fab fa-whatsapp"></i>
        </a>
        <a href="https://www.instagram.com/jp.joyas/" target="_blank" class="text-black hover:text-gray-700 text-3xl" aria-label="Instagram">
          <i class="fab fa-instagram"></i>
        </a>
        <a href="https://www.facebook.com/JuanPabloOsorioJP/" target="_blank" class="text-black hover:text-gray-700 text-3xl" aria-label="Facebook">
          <i class="fab fa-facebook"></i>
        </a>
      </div>
    </div>
    
  </section>
  
  <div class="flex justify-center mb-12">
    
    <img src="<?php echo e(asset('images/home-mobile.jpg')); ?>" class="block md:hidden h-auto w-auto rounded-xl shadow-lg">

    
    <img src="<?php echo e(asset('images/home.jpg')); ?>" class="hidden md:block h-auto w-auto rounded-xl shadow-lg">
  </div>
  
  <h2 class="px-6 text-center md:text-left font-dragonwick text-3xl font-semibold text-gray-800 mb-4">Servicios</h2>
  <section id="servicios" class="grid gap-8 md:grid-cols-2 bg-gray-300 rounded-lg shadow p-6 mb-16">
    
    
    <div class="border border-gray-500 rounded-lg p-4 shadow hover:shadow-md transition">
      <h3 class="text-xl font-bold text-gray-800 mb-2">Joyas personalizadas</h3>
      <p class="text-gray-600">
        Diseña la joya perfecta para esa persona especial. Pulsera, colgante, anillo o aros personalizados con nombre, color o gema que la represente. ¡Crea un diseño único y haz que brille!
      </p>
    </div>

    
    <div class="border border-gray-500 rounded-lg p-4 shadow hover:shadow-md transition">
      <h3 class="text-xl font-bold text-gray-800 mb-2">Atención a domicilio</h3>
      <p class="text-gray-600">
        En Villarrica tienes la ventaja de poder recibir una atención personalizada a domicilio quedando a tu elección si es desde mi auto o dentro de tu casa, donde más te acomode. En el radio urbano y sectores rurales cercanos.
      </p>
    </div>

    
    <div class="border border-gray-500 rounded-lg p-4 shadow hover:shadow-md transition">
      <h3 class="text-xl font-bold text-gray-800 mb-2">Reparaciones</h3>
      <p class="text-gray-600">
        ¿Tienes una joya de plata que ya no usas por un defecto o se dañó? No la deseches. ¡Comunícate conmigo y la reparo! Arreglo de soldaduras y restauración de joyas al precio más conveniente.
      </p>
    </div>

    
    <div class="border border-gray-500 rounded-lg p-4 shadow hover:shadow-md transition">
      <h3 class="text-xl font-bold text-gray-800 mb-2">Entrega de regalos sorpresa</h3>
      <p class="text-gray-600">
        ¿Quieres sorprender a alguien especial desde lejos? Elige tu joya favorita y yo me encargo de entregarla directamente a esa persona especial. Puedes incluir una caja joyero personalizada para hacer el regalo aún más especial. Cumpleaños, aniversarios o cualquier ocasión es perfecta.
      </p>
    </div>

  </section>


  
  <h2 class="px-6 text-center md:text-left font-dragonwick text-3xl font-semibold text-gray-800 mb-4">Presentacion</h2>
  <section id="presentacion" class="relative mb-16 bg-gray-300 rounded-lg shadow p-6">
    
    
    <div class="border border-gray-500 rounded-lg p-4 shadow hover:shadow-md transition">
      <?php if(auth()->guard()->check()): ?>
        <?php if(Auth::user()->is_admin): ?>
          <div class="absolute top-4 right-4">
            <?php if (isset($component)) { $__componentOriginal8417baeedcb6c131165d53e37e61cc07 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8417baeedcb6c131165d53e37e61cc07 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.edit-button','data' => ['href' => route('info.edit', 'descripcion')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('edit-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('info.edit', 'descripcion'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8417baeedcb6c131165d53e37e61cc07)): ?>
<?php $attributes = $__attributesOriginal8417baeedcb6c131165d53e37e61cc07; ?>
<?php unset($__attributesOriginal8417baeedcb6c131165d53e37e61cc07); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8417baeedcb6c131165d53e37e61cc07)): ?>
<?php $component = $__componentOriginal8417baeedcb6c131165d53e37e61cc07; ?>
<?php unset($__componentOriginal8417baeedcb6c131165d53e37e61cc07); ?>
<?php endif; ?>
          </div>
        <?php endif; ?>
      <?php endif; ?>

      <p class="text-gray-600 leading-relaxed text-xl">
        <?php echo $descripcion ?? 'Aquí va la descripción de JP Joyas.'; ?>

      </p>
    </div>
  </section>
  
  <h2 class="px-6 text-center md:text-left font-dragonwick text-3xl font-semibold text-gray-800 mb-4">Quien Soy</h2>
  <section id="historia" class="relative mb-16 bg-gray-300 rounded-lg shadow p-6">
    
    
    <div class="border border-gray-500 rounded-lg p-4 shadow hover:shadow-md transition">
      <?php if(auth()->guard()->check()): ?>
        <?php if(Auth::user()->is_admin): ?>
          <div class="absolute top-4 right-4">
            <?php if (isset($component)) { $__componentOriginal8417baeedcb6c131165d53e37e61cc07 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8417baeedcb6c131165d53e37e61cc07 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.edit-button','data' => ['href' => route('info.edit', 'historia')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('edit-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('info.edit', 'historia'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8417baeedcb6c131165d53e37e61cc07)): ?>
<?php $attributes = $__attributesOriginal8417baeedcb6c131165d53e37e61cc07; ?>
<?php unset($__attributesOriginal8417baeedcb6c131165d53e37e61cc07); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8417baeedcb6c131165d53e37e61cc07)): ?>
<?php $component = $__componentOriginal8417baeedcb6c131165d53e37e61cc07; ?>
<?php unset($__componentOriginal8417baeedcb6c131165d53e37e61cc07); ?>
<?php endif; ?>
          </div>
        <?php endif; ?>
      <?php endif; ?>
      <p class="text-gray-600 leading-relaxed text-xl">
        <?php echo $historia ?? 'Aquí va la historia.'; ?>

      </p>
    </div>

    </section>

  
  <section>
    <div class="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
      
      <h2 class="px-6 text-center md:text-left font-dragonwick text-3xl font-semibold text-gray-800 mb-4 md:mb-0">
        Blog
      </h2>
      
      <?php if(auth()->guard()->check()): ?>
        <a href="<?php echo e(route('blog.create')); ?>"
          class="inline-block bg-blue-100 text-blue-800 font-semibold px-4 py-2 rounded-lg border border-blue-300 hover:bg-blue-200 transition text-center">
          + Nueva publicación
        </a>
      <?php endif; ?>
    </div>

    <?php if($posts->isEmpty()): ?>
      <div class="relative bg-gray-300 p-6 rounded-lg shadow hover:shadow-md transition">
        <p class="text-gray-800">No hay publicaciones aún.</p>
      </div>
    <?php else: ?>
      <div class="space-y-8">
        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <article class="relative bg-gray-300 p-6 rounded-lg shadow hover:shadow-md transition">
          

          <div class="flex flex-col md:flex-row md:items-start gap-6">
            
            
            
            <div class="flex-1 min-w-0">
              <h3 class="text-2xl font-bold text-gray-800 mb-1"><?php echo e($post->title); ?></h3>
              <p class="text-sm text-gray-500 mb-3">
                  por <?php echo e($post->user->name); ?> · <?php echo e($post->created_at->format('d M Y')); ?>

              </p>

              <div class="prose max-w-none text-gray-700 break-words mb-4">
                  <?php echo $post->preview_text; ?>

              </div>

              
              <div class="flex items-center space-x-2">
                  
                  <?php if (isset($component)) { $__componentOriginale91f24f192f79f911477623e23179d51 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale91f24f192f79f911477623e23179d51 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.view-button','data' => ['href' => route('blog.show', $post)]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('view-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('blog.show', $post))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale91f24f192f79f911477623e23179d51)): ?>
<?php $attributes = $__attributesOriginale91f24f192f79f911477623e23179d51; ?>
<?php unset($__attributesOriginale91f24f192f79f911477623e23179d51); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale91f24f192f79f911477623e23179d51)): ?>
<?php $component = $__componentOriginale91f24f192f79f911477623e23179d51; ?>
<?php unset($__componentOriginale91f24f192f79f911477623e23179d51); ?>
<?php endif; ?>

                  
                  <?php if(auth()->guard()->check()): ?>
                      <?php if(Auth::id() === $post->user_id): ?>
                          <?php if (isset($component)) { $__componentOriginal8417baeedcb6c131165d53e37e61cc07 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8417baeedcb6c131165d53e37e61cc07 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.edit-button','data' => ['href' => route('blog.edit', $post)]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('edit-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('blog.edit', $post))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8417baeedcb6c131165d53e37e61cc07)): ?>
<?php $attributes = $__attributesOriginal8417baeedcb6c131165d53e37e61cc07; ?>
<?php unset($__attributesOriginal8417baeedcb6c131165d53e37e61cc07); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8417baeedcb6c131165d53e37e61cc07)): ?>
<?php $component = $__componentOriginal8417baeedcb6c131165d53e37e61cc07; ?>
<?php unset($__componentOriginal8417baeedcb6c131165d53e37e61cc07); ?>
<?php endif; ?>
                          <?php if (isset($component)) { $__componentOriginalec2502b834f860c8e30d229aa8f280e2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalec2502b834f860c8e30d229aa8f280e2 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.delete-button','data' => ['action' => route('blog.destroy', $post)]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('delete-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['action' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('blog.destroy', $post))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalec2502b834f860c8e30d229aa8f280e2)): ?>
<?php $attributes = $__attributesOriginalec2502b834f860c8e30d229aa8f280e2; ?>
<?php unset($__attributesOriginalec2502b834f860c8e30d229aa8f280e2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalec2502b834f860c8e30d229aa8f280e2)): ?>
<?php $component = $__componentOriginalec2502b834f860c8e30d229aa8f280e2; ?>
<?php unset($__componentOriginalec2502b834f860c8e30d229aa8f280e2); ?>
<?php endif; ?>
                      <?php endif; ?>
                  <?php endif; ?>
              </div>
            </div>

            
            <?php if($post->preview_image): ?>
              <div class="w-full md:w-1/3 flex-shrink-0 flex justify-center items-start">
                <div class="max-w-[200px] w-full">
                  <?php echo $post->preview_image; ?>

                </div>
              </div>
            <?php endif; ?>

          </div>
        </article>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


      </div>
    <?php endif; ?>
  </section>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\pablo\OneDrive\Documentos\JpJoyas\JpJoyas\jpjoyas\resources\views\home.blade.php ENDPATH**/ ?>