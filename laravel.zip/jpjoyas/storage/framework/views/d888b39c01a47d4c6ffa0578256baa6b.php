<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <link rel="icon" href="<?php echo e(asset('favicon.svg')); ?>" type="image/svg+xml">

        <title><?php echo e(config('app.name', 'Laravel')); ?></title>

        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />
        <!-- Font Awesome CDN -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
        
        <!-- Scripts -->
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
        <?php if (isset($component)) { $__componentOriginal95950f824213f5cf8d19afcb8f4ecb86 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal95950f824213f5cf8d19afcb8f4ecb86 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => '71ffe14e2608a75a2cb5aed52d105549::styles','data' => ['theme' => 'richtextlaravel','dataTurboTrack' => 'false']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('rich-text::styles'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['theme' => 'richtextlaravel','data-turbo-track' => 'false']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal95950f824213f5cf8d19afcb8f4ecb86)): ?>
<?php $attributes = $__attributesOriginal95950f824213f5cf8d19afcb8f4ecb86; ?>
<?php unset($__attributesOriginal95950f824213f5cf8d19afcb8f4ecb86); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal95950f824213f5cf8d19afcb8f4ecb86)): ?>
<?php $component = $__componentOriginal95950f824213f5cf8d19afcb8f4ecb86; ?>
<?php unset($__componentOriginal95950f824213f5cf8d19afcb8f4ecb86); ?>
<?php endif; ?>
        <!-- Trix Editor -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/trix/2.0.0/trix.min.css">
        <script src="https://cdnjs.cloudflare.com/ajax/libs/trix/2.0.0/trix.umd.min.js"></script>
    </head>

    <body class="font-sans antialiased bg-fixed bg-no-repeat bg-top bg-black" style="background-image: url('/images/fondo-jpjoyas.jpg'); background-size: contain;">
        <div class="flex flex-col min-h-screen bg-black/30">
            <?php echo $__env->make('layouts.navigation', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            <!-- Page Heading -->
            <?php if(isset($header)): ?>
                <header class="bg-white shadow">
                    <div class="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
                        <?php echo e($header); ?>

                    </div>
                </header>
            <?php endif; ?>

            <!-- Page Content -->
            <main>
                <?php echo $__env->yieldContent('content'); ?> 
            </main>

            <footer class="bg-black mt-16 border-t border-gray-900">
                <div class="max-w-4xl mx-auto px-6 py-8 text-center text-sm text-gray-100">
                    <p class="mb-4 font-semibold"> Contáctame solo por teléfono o WhatsApp</p>
                    <div class="flex justify-center space-x-6">
                    <a href="https://wa.me/message/RCSEZTH4EZGMA1" target="_blank" class="text-green-600 hover:text-green-800 text-3xl" aria-label="WhatsApp">
                        <i class="fab fa-whatsapp"></i>
                    </a>
                    <a href="https://www.instagram.com/jp.joyas/" target="_blank" class="text-pink-500 hover:text-pink-700 text-3xl" aria-label="Instagram">
                        <i class="fab fa-instagram"></i>
                    </a>
                    <a href="https://www.facebook.com/JuanPabloOsorioJP/" target="_blank" class="text-blue-600 hover:text-blue-800 text-3xl" aria-label="Facebook">
                        <i class="fab fa-facebook"></i>
                    </a>
                    </div>
                    <p class="mt-4 text-gray-400">&copy; <?php echo e(date('Y')); ?> JP Joyas · Villarrica</p>
                </div>
            </footer>

        </div>

        <script>
            document.addEventListener("trix-attachment-add", function (event) {
                const attachment = event.attachment;
                if (attachment.file) {
                uploadTrixImage(attachment);
                }
            });

            function uploadTrixImage(attachment) {
                // FormData para enviar la imagen
                const file = attachment.file;
                const form = new FormData();
                form.append("attachment", file);

                // Enviar POST a endpoint Laravel
                fetch("/trix-upload", {
                method: "POST",
                headers: {
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
                },
                body: form,
                })
                .then(response => response.json())
                .then(result => {
                // Una vez subida, le pasamos la URL real a Trix
                attachment.setAttributes({
                    url: result.url,
                    href: result.url
                });
                })
                .catch(error => {
                console.error("Error al subir imagen a Trix:", error);
                });
            }
        </script>
    </body>
</html>
<?php /**PATH C:\Users\pablo\OneDrive\Documentos\JpJoyas\JpJoyas\jpjoyas\resources\views\layouts\app.blade.php ENDPATH**/ ?>