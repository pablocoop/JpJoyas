<?php $__env->startSection('content'); ?>
<div class="max-w-4xl mx-auto mt-10 bg-white p-6 rounded shadow">
  <h1 class="text-2xl font-bold mb-4">Editar <?php echo e(ucfirst($section)); ?></h1>

  <form action="<?php echo e(route('info.update', $section)); ?>" method="POST">
    <?php echo csrf_field(); ?>

    
    <input id="body" type="hidden" name="body" value="<?php echo old('body', $content->body); ?>">
    <trix-editor input="body" class="trix-content"></trix-editor>
    <button type="submit"
            class="mt-4 bg-blue-600 text-white px-6 py-2 rounded hover:bg-blue-700">
        Guardar cambios
    </button>
  </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\pablo\OneDrive\Documentos\JpJoyas\JpJoyas\jpjoyas\resources\views\admin\edit-info.blade.php ENDPATH**/ ?>