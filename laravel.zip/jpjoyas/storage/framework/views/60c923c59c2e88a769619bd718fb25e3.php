<?php $__env->startSection('content'); ?>
<div class="mx-auto max-w-4xl px-6 py-20 bg-gray-300/70 backdrop-blur rounded-lg mt-8">
    <h1 class="text-3xl font-bold mb-6">Editar Post</h1>

    <form method="POST" action="<?php echo e(route('blog.update', $post)); ?>" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        
        <div class="mb-4">
            <label class="block font-medium mb-1">Título</label>
            <input type="text" name="title" value="<?php echo e(old('title', $post->title)); ?>"
                   class="w-full border rounded px-3 py-2 focus:outline-none focus:ring focus:border-blue-300" required>
        </div>

        
        <div class="mb-4">
            <label class="block font-medium mb-1">Contenido</label>
            <input id="body" type="hidden" name="body" value="<?php echo e(old('body', $post->body)); ?>">
            <trix-editor input="body" class="trix-content bg-white border rounded px-3 py-2"></trix-editor>
        </div>

        
        <div class="mb-4">
            <label class="block font-medium mb-1">Imagen destacada (opcional)</label>
            <?php if($post->image_path): ?>
                <div class="mb-2">
                    <img src="<?php echo e(asset('storage/' . $post->image_path)); ?>" class="w-48 rounded shadow">
                </div>
            <?php endif; ?>
            <input type="file" name="image" class="w-full border px-3 py-2 rounded">
        </div>

        
        <div class="mb-6">
            <label class="block font-medium mb-1">Video (opcional)</label>
            <?php if($post->video_path): ?>
                <div class="mb-2">
                    <video controls class="w-full rounded shadow">
                        <source src="<?php echo e(asset('storage/' . $post->video_path)); ?>" type="video/mp4">
                        Tu navegador no soporta video.
                    </video>
                </div>
            <?php endif; ?>
            <input type="file" name="video" class="w-full border px-3 py-2 rounded">
        </div>

        
        <div class="flex justify-between items-center">
            <a href="<?php echo e(route('home')); ?>" class="text-red-600 hover:underline">Cancelar</a>
            <button type="submit"
                    class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 transition">
                Actualizar Post
            </button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\pablo\OneDrive\Documentos\JpJoyas\JpJoyas\jpjoyas\resources\views\blog\edit.blade.php ENDPATH**/ ?>