<span>&#8864;</span>
<?php /**PATH C:\Users\pablo\OneDrive\Documentos\JpJoyas\JpJoyas\jpjoyas\vendor\tonysm\rich-text-laravel\resources\views\attachables\_missing_attachable.blade.php ENDPATH**/ ?>