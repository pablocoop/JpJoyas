<figure class="attachment attachment--content">
<?php echo trim($content->renderTrixContentAttachment($options)); ?>

</figure>
<?php /**PATH C:\Users\pablo\OneDrive\Documentos\JpJoyas\JpJoyas\jpjoyas\vendor\tonysm\rich-text-laravel\resources\views\attachables\_content.blade.php ENDPATH**/ ?>