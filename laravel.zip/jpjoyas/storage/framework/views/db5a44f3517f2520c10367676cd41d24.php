

<?php $__env->startSection('content'); ?>
    <div class="max-w-lg mx-auto bg-white shadow p-6 rounded">
        <h1 class="text-2xl font-bold mb-4">Crear nuevo post</h1>

        <?php if(session('success')): ?>
            <div class="mb-4 text-green-600"><?php echo e(session('success')); ?></div>
        <?php endif; ?>

        <?php if($errors->any()): ?>
            <div class="mb-4 text-red-600">
                <ul class="list-disc pl-5">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <form action="<?php echo e(route('blog.store')); ?>" method="POST" enctype="multipart/form-data" class="space-y-4">
            <?php echo csrf_field(); ?>
            <div>
                <label class="block font-medium">Título</label>
                <input type="text" name="title" class="w-full border rounded px-3 py-2" value="<?php echo e(old('title')); ?>" required>
            </div>
            <div>
                <label class="block font-medium">Contenido</label>
                <input id="body" type="hidden" name="body" value="<?php echo e(old('body')); ?>">
                <trix-editor input="body" class="trix-content bg-white border rounded px-3 py-2"></trix-editor>
            </div>
            <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded">Publicar</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\pablo\OneDrive\Documentos\JpJoyas\JpJoyas\jpjoyas\resources\views\blog\create.blade.php ENDPATH**/ ?>