<?php return array (
  'blade-ui-kit/blade-icons' => 
  array (
    'providers' => 
    array (
      0 => 'BladeUI\\Icons\\BladeIconsServiceProvider',
    ),
  ),
  'laravel/tinker' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Tinker\\TinkerServiceProvider',
    ),
  ),
  'mallardduck/blade-lucide-icons' => 
  array (
    'providers' => 
    array (
      0 => 'MallardDuck\\LucideIcons\\BladeLucideIconsServiceProvider',
    ),
  ),
  'nesbot/carbon' => 
  array (
    'providers' => 
    array (
      0 => 'Carbon\\Laravel\\ServiceProvider',
    ),
  ),
  'nunomaduro/termwind' => 
  array (
    'providers' => 
    array (
      0 => 'Termwind\\Laravel\\TermwindServiceProvider',
    ),
  ),
  'tonysm/globalid-laravel' => 
  array (
    'aliases' => 
    array (
      'GlobalId' => 'Tonysm\\GlobalId\\GlobalIdFacade',
    ),
    'providers' => 
    array (
      0 => 'Tonysm\\GlobalId\\GlobalIdServiceProvider',
    ),
  ),
  'tonysm/rich-text-laravel' => 
  array (
    'providers' => 
    array (
      0 => 'Tonysm\\RichTextLaravel\\RichTextLaravelServiceProvider',
    ),
  ),
);